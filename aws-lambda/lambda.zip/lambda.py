def lambda_handler(event, context):
    print ("Hello from terraform world")
    return "hello from terraform world"
